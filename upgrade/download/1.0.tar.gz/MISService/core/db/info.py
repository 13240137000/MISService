class LogInfo(object):
    pass
